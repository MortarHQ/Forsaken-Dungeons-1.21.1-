Item      | Model Data  |  Mc item
----------|-------------|----------------------
Wands     |   1xxx      |  goat_horn
Passive   |   2xxx      |  stick
Weapon    |   3xxx      |  wooden_sword / flint
Armor     |   4xxx      |  leather_armor (head = 4000..4249, chest = 4250..4499, ...)
Shards    |   5xxx      |  amethyst_shard
.         |             | 
Symbols   |   6xxx      |  slime_ball /leather_horse_armor
Enemies   |   7xxx      |  ''
Traps     |   8xxx      |  ''
Models    |   9xxx      |  ''
.         |             | 
Markers   |   9xxx      |  carrot_on_a_stick

