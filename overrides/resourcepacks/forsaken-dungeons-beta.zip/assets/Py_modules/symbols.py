# Last: uF3b6

def symbols(file):
    stats = [
            ("hp","\\uF810"),
            ("dmg","\\uF811"),
            ("attack_speed","\\uF812"),
            ("speed","\\uF813"),
            ("armor","\\uF814"),
            ("armor_toughness","\\uF815"),
            ("knock_resist","\\uF816"),
            ("mana_capacity","\\uF817"),
            ("mana_speed","\\uF818"),
            ("mana_cost","\\uF819"),
            ("souls_capacity","\\uF81a"),
            ("luck","\\uF81b"),
            ("curse","\\uF81c"),
            ("attack_range","\\uF3b6")
        ]
    for stat in stats:
        file.write("""
            {{
                "type": "bitmap",
                "file": "fd:symbols/stats/{}.png",
                "ascent": 8,
                "height": 8,
                "chars": ["{}"]
            }},""".format(stat[0], stat[1]))


    file.write("""
        {
            "type": "bitmap",
            "file": "fd:symbols/coin/meta.png",
            "ascent": 11,
            "height": 14,
            "chars": ["\\uF81d"]
        },
        {
            "type": "bitmap",
            "file": "fd:symbols/coin/copper.png",
            "ascent": 8,
            "height": 9,
            "chars": ["\\uF81e"]
        },""")

    effects = [
            ("fire","\\uF830"),
            ("spore_poison","\\uF831"),
            ("freeze","\\uF832"),
            ("mage_armor","\\uF833"),
            ("mana_flow","\\uF834"),
            ("dark_curse","\\uF835"),
        ]
    for effect in effects:
        file.write("""
            {{
                "type": "bitmap",
                "file": "fd:symbols/effects/{}.png",
                "ascent": -16,
                "height": 9,
                "chars": ["{}"]
            }},""".format(effect[0], effect[1]))

    symbols = [
            ("trophy","\\uF3C6"),
            ("video_game","\\uF3AE"),
            ("language","\\uF3af"),
            ("builder","\\uF3b0"),
            ("modeler","\\uF3b1"),
            ("texturer","\\uF3b2"),
            ("right_click","\\uF3b3"),
            ("shift_key","\\uF3b4"),
            ("q_key","\\uF3b5"),
        ]
    for symbol in symbols:
        file.write("""
            {{
                "type": "bitmap",
                "file": "fd:symbols/info/{}.png",
                "ascent": 8,
                "height": 9,
                "chars": ["{}"]
            }},""".format(symbol[0], symbol[1]))