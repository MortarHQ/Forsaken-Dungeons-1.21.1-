from map import *
from symbols import *
import sys

# unicode free uE00 - F8FF
#   · Negative spaces takes f800-f80f & f820-f82f

f = open('../minecraft/font/default.json', 'w')
f.write("""
{
    "providers": [
""")

image = '-i' in sys.argv
map_all(f, image)
symbols(f)

sf = open('spaces.json', 'r')

f.writelines(sf.readlines())

f.write("""
    ]
}""")
f.close()
