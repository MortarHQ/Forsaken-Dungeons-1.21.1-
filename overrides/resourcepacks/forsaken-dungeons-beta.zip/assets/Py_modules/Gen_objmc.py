import os
from enum import Enum
from natsort import os_sorted
import subprocess

objmc_path = '"C:/Users/mattc/Desktop/Forsaken Dungeons stuff/objmc/objmc.py"'
src_root = 'C:/Users/mattc/Desktop/Forsaken Dungeons stuff/objmc'
des_root = 'C:/Users/mattc/AppData/Roaming/.minecraft/resourcepacks/Forsaken Dungeons Resourcepack/assets/objmc'

class Op (Enum):
    noflipuv = 1
    noautoplay = 2

def objmc(anim_folder:str, texture_path:str, dest_texture_path:str, dest_model_path:str, texture_ref:str, flipuv:bool=False, autoplay:bool=True, colorbehavior:tuple[str] = ("time", "time", "overlay")):
    # Get objs
    animation_files = [f'"{anim_folder}/{f}"' for f in os_sorted(os.listdir(anim_folder)) if f.endswith('.obj')]

    # Generate animation
    cmd = ( 'python', objmc_path, "--objs" )
    cmd += tuple(animation_files)
    cmd += (
        "--texs", texture_path, 
        "--out", "out.json", "out.png", 
        "--easing", "3", 
        "--duration", str(len(animation_files)), 
        "--colorbehavior", colorbehavior[0], colorbehavior[1], colorbehavior[2],
        "--autorotate", "3"
    )
    if (flipuv): cmd += ('--flipuv', )
    if (autoplay): cmd += ('--autoplay', )
    subprocess.call(cmd)

    # Assign texture reference
    with open('out.json', 'r') as file:
        filedata = file.read()
    filedata = filedata.replace('out', texture_ref)
    with open('out.json', 'w') as file:
        file.write(filedata)

    # Move files to destinationsº
    if os.path.isfile(dest_model_path): os.remove(dest_model_path)
    if os.path.isfile(dest_texture_path): os.remove(dest_texture_path)
    os.rename('out.json', dest_model_path)
    os.rename('out.png', dest_texture_path)

def grouped(name:str, type:str, animations:dict[list[str|Op]], texture:str=None, flipuv=True):
    for animation, settings in animations.items():

        if texture is None: texture = name

        animation_name = animation
        for setting in settings:
            if isinstance(setting, str):
                animation_name = setting

        objmc(
            f'{src_root}/{type}/{name}/{animation}',
            f'{src_root}/{type}/{name}/{texture}.png',
            f'{des_root}/textures/{type}/{name}/{animation}.png',
            f'{des_root}/models/{type}/{name}/base_model/{animation_name}.json',
            f'objmc:{type}/{name}/{animation}',
            not Op.noflipuv in settings and flipuv,
            not Op.noautoplay in settings
        )

def creator(name:str, animation:str, texture:str=None):
    objmc(
        f'{src_root}/mob/{name}/{animation}',
        f'{src_root}/mob/{name}/{texture}.png',
        f'{des_root}/textures/creator/{name}.png',
        f'{des_root}/models/creator/{name}.json',
        f'objmc:creator/{name}',
        True,
        True,
        ("time", "time", "yaw")
    )

def contributor(name:str, animation:str, texture:str=None, isSlim:bool=False, flipuv=True):
    slim = "_slim" if isSlim else ""
    objmc(
        f'{src_root}/mob/player{slim}/{animation}',
        f'{src_root}/mob/player{slim}/src/{texture}.png',
        f'{des_root}/textures/contributors/{name}-{animation}.png',
        f'{des_root}/models/contributors/base_model{slim}.json',
        f'objmc:contributors/{name}-{animation}',
        flipuv,
        True,
        ("time", "time", "yaw")
    )

    with open(f'{des_root}/models/contributors/{name}-{animation}.json', 'w') as f:
        f.write(
f"""
{{
    "parent":"objmc:contributors/base_model{slim}",
    "textures":{{"0":"objmc:contributors/{name}-{animation}"}}
}}"""
        )

if __name__ == '__main__':

    # grouped( "annoying_seagull",    "mob", {"fly":(), "death":()} )
    # grouped( "automaton",           "mob", {"walk":["20_ticks"], "death":["20_ticks"], "idle":["0_ticks", Op.noflipuv, Op.noautoplay]} )
    # grouped( "copper_golem",        "mob", {"walk":["40_ticks"], "death":["20_ticks"], "idle_tick":["40_ticks"]} )
    # grouped( "crazy_engineer",      "mob", {"walk":["20_ticks"], "death":["20_ticks"], "idle":["0_ticks"], "walk_attack":["20_ticks"], "build":[]}, "all", False)
    # grouped( "flying_machine",      "mob", {"fly":[], "death":[]} )
    grouped( "hermit_crab",         "mob", {"walk":["20_ticks"], "death":["20_ticks"], "idle":["40_ticks"], "hide":["0_ticks", Op.noflipuv, Op.noautoplay]} )
    # creator("youknowwhen",            "cast", "youknowwhen-src")
    # contributor("piro_oh",       "seat-floor",   "piro_oh",     True, False)
    # contributor("celestepic",           "layback",      "celestepic",         True)
    # contributor("end_mysuffering",      "seat",         "end_mysuffering",    True)
    # contributor("valera2013",           "seat",         "valera2013",         True)
    # contributor("hydroangeas",          "layback",      "hydroangeas", flipuv=True)
    # contributor("jonloveslegos",        "seat-sleep",   "jonloveslegos", flipuv=True)
    # contributor("min3rminor",           "sneak",        "min3rminor", flipuv=True)
    # contributor("red1854th",            "seat",         "red1854th", flipuv=True)
    # contributor("sedona1029",           "read",         "sedona1029", flipuv=True)
    # contributor("yekc",                 "hang-block",   "yekc", flipuv=True)
    # contributor("youknowwho",           "seat2",        "youknowwho", flipuv=True)
    pass